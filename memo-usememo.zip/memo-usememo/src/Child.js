import React from "react";

//Child.js
function Child({memoizedValue}) { 
  console.log("Child Render"); 

  return (
  <div> 
    <h2> 
          Rendered: {memoizedValue}
    </h2>
  </div> 
 )
} 

export default Child;