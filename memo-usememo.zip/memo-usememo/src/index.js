import { StrictMode } from "react";
import ReactDOM from "react-dom";

import Parent from "./Parent";

const rootElement = document.getElementById("root");
ReactDOM.render(
  <StrictMode>
    <Parent />
  </StrictMode>,
  rootElement
);
