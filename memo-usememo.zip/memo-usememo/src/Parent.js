import Child from "./Child";
import React from "react";
import { useState, useRef, useMemo} from "react";

//Parent.js
export default function Parent() { 
  const [counts, setCounts] = useState(0); 
  const useMemoRef = useRef(0);
  const incrementUseMemoRef = () => useMemoRef.current++; 
  const memoizedValue = useMemo(() => incrementUseMemoRef(), [counts]); 

console.log("Parent Render"); 
console.log(memoizedValue); 
return ( 
  <div> 
    <button onClick={() => setCounts(counts+1)}>Increase Count</button> 
    <Child memoizedValue={memoizedValue} /> 
  </div> 
  )
 }